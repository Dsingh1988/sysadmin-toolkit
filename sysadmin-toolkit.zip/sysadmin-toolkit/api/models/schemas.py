"""
Shared Pydantic models and script execution utility.
"""
import subprocess
import shlex
import os
from datetime import datetime
from typing import Optional, List
from pydantic import BaseModel
from fastapi import HTTPException


class ScriptResult(BaseModel):
    """Standard response model for script execution results."""
    success: bool
    exit_code: int
    stdout: str
    stderr: str
    timestamp: str
    hostname: str
    duration_ms: Optional[float] = None


def run_script(script_path: str, args: List[str] = [], timeout: int = 120) -> ScriptResult:
    """
    Executes a bash script and returns structured output.

    Args:
        script_path: Relative path to the script
        args: List of argument strings
        timeout: Execution timeout in seconds (default 120)

    Returns:
        ScriptResult with stdout, stderr, exit_code
    """
    # Resolve absolute path relative to api/ directory
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    abs_path = os.path.normpath(os.path.join(base_dir, script_path.lstrip("../")))

    if not os.path.isfile(abs_path):
        raise HTTPException(status_code=404, detail=f"Script not found: {script_path}")

    cmd = ["bash", abs_path] + shlex.split(" ".join(args))

    start = datetime.utcnow()
    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        duration = (datetime.utcnow() - start).total_seconds() * 1000

        return ScriptResult(
            success=result.returncode == 0,
            exit_code=result.returncode,
            stdout=result.stdout,
            stderr=result.stderr,
            timestamp=datetime.utcnow().isoformat(),
            hostname=os.uname().nodename,
            duration_ms=round(duration, 2),
        )
    except subprocess.TimeoutExpired:
        raise HTTPException(status_code=408, detail=f"Script timed out after {timeout}s")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
