"""
Linux SysAdmin Automation Toolkit — FastAPI REST Interface
=========================================================
Author  : Devendra Singh Chouhan <debuchouhan@gmail.com>
GitHub  : https://github.com/Dsingh1988/sysadmin-toolkit
License : MIT

Provides a REST API to trigger automation scripts remotely.
Useful for integration with Grafana, Prometheus, Zabbix, or custom dashboards.

Usage:
    pip install -r requirements.txt
    uvicorn main:app --host 0.0.0.0 --port 8000 --reload

Docs: http://localhost:8000/docs
"""

import subprocess
import shlex
import os
from datetime import datetime
from typing import Optional

from fastapi import FastAPI, HTTPException, BackgroundTasks, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from routes import disk, network, security, services, users

# ─── App Setup ────────────────────────────────────────────────────────────────
app = FastAPI(
    title="Linux SysAdmin Automation Toolkit API",
    description="""
## 🛠️ SysAdmin Automation REST API

Execute Linux automation scripts remotely via HTTP.

### Modules
- **Disk** — SMART health, LVM thin-pool, NAS mount checks
- **Network** — NIC audit, DNS bulk check, firewall audit
- **Security** — SSH audit/hardening, CIS benchmark, failed login report
- **Services** — Systemd sweep, Pacemaker cluster health
- **Users** — Sudo audit, stale account detection

> ⚠️ This API executes system commands. Deploy behind an authenticated reverse proxy (Nginx + OAuth2/mTLS).
    """,
    version="1.0.0",
    contact={
        "name": "Devendra Singh Chouhan",
        "email": "debuchouhan@gmail.com",
        "url": "https://github.com/Dsingh1988/sysadmin-toolkit",
    },
    license_info={"name": "MIT"},
)

# ─── CORS ─────────────────────────────────────────────────────────────────────
app.add_middleware(
    CORSMiddleware,
    allow_origins=os.getenv("ALLOWED_ORIGINS", "*").split(","),
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)

# ─── Routers ──────────────────────────────────────────────────────────────────
app.include_router(disk.router,     prefix="/api/v1/disk",     tags=["Disk & Storage"])
app.include_router(network.router,  prefix="/api/v1/network",  tags=["Network"])
app.include_router(security.router, prefix="/api/v1/security", tags=["Security"])
app.include_router(services.router, prefix="/api/v1/services", tags=["Services"])
app.include_router(users.router,    prefix="/api/v1/users",    tags=["User Management"])


# ─── Root ─────────────────────────────────────────────────────────────────────
@app.get("/", tags=["Info"])
async def root():
    return {
        "name": "Linux SysAdmin Automation Toolkit",
        "version": "1.0.0",
        "author": "Devendra Singh Chouhan",
        "github": "https://github.com/Dsingh1988/sysadmin-toolkit",
        "docs": "/docs",
        "health": "/health",
    }


@app.get("/health", tags=["Info"])
async def health_check():
    return {
        "status": "healthy",
        "timestamp": datetime.utcnow().isoformat(),
        "hostname": os.uname().nodename,
        "python_version": f"{os.sys.version_info.major}.{os.sys.version_info.minor}",
    }
