"""Network API Routes"""
from fastapi import APIRouter, Query
from models.schemas import ScriptResult, run_script

router = APIRouter()
SCRIPTS_BASE = "../scripts"

@router.get("/audit", summary="Network interface audit", response_model=ScriptResult)
async def network_audit(verbose: bool = Query(False)):
    args = ["--verbose"] if verbose else []
    return run_script(f"{SCRIPTS_BASE}/network/network_audit.sh", args)

@router.get("/dns-check", summary="Bulk DNS zone health check", response_model=ScriptResult)
async def dns_check(resolver: str = Query("8.8.8.8", description="DNS resolver IP")):
    return run_script(f"{SCRIPTS_BASE}/network/dns_bulk_check.sh", [f"--resolver {resolver}"])

@router.get("/firewall-audit", summary="Firewall rules audit", response_model=ScriptResult)
async def firewall_audit():
    return run_script(f"{SCRIPTS_BASE}/network/firewall_audit.sh", [])
