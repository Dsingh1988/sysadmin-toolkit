"""Disk & Storage API Routes"""
import subprocess
import shlex
from typing import Optional
from fastapi import APIRouter, HTTPException, Query
from models.schemas import ScriptResult, run_script

router = APIRouter()

SCRIPTS_BASE = "../scripts"


@router.get("/health", summary="Run disk health check", response_model=ScriptResult)
async def disk_health(
    threshold: int = Query(85, ge=1, le=100, description="Alert threshold %"),
    json_output: bool = Query(False, description="Return JSON output from script"),
):
    """
    Runs `disk_health_check.sh` — checks filesystem usage, SMART status,
    LVM VGs, thin-pool usage, and inode usage.
    """
    args = [f"--threshold {threshold}"]
    if json_output:
        args.append("--json")
    return run_script(f"{SCRIPTS_BASE}/disk/disk_health_check.sh", args)


@router.get("/lvm-pools", summary="Check LVM thin-pool usage", response_model=ScriptResult)
async def lvm_thin_pools(
    threshold: int = Query(80, ge=1, le=100, description="Alert threshold %"),
):
    """
    Runs `lvm_thin_pool_monitor.sh` — reports data% and metadata% for all thin pools.
    Alert if either exceeds threshold (default 80%).
    """
    return run_script(f"{SCRIPTS_BASE}/disk/lvm_thin_pool_monitor.sh", [f"--threshold {threshold}"])


@router.get("/nas-mounts", summary="Verify NAS mount points", response_model=ScriptResult)
async def nas_mounts():
    """
    Runs `nas_mount_verify.sh` — validates NFS/CIFS mount accessibility and latency.
    """
    return run_script(f"{SCRIPTS_BASE}/disk/nas_mount_verify.sh", [])
