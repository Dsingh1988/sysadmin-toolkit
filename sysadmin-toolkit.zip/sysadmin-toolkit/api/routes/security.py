"""Security API Routes"""
from fastapi import APIRouter, Query
from models.schemas import ScriptResult, run_script

router = APIRouter()
SCRIPTS_BASE = "../scripts"

@router.get("/ssh-audit", summary="Audit SSH configuration (CIS Benchmark)", response_model=ScriptResult)
async def ssh_audit():
    """Runs ssh_hardening.sh in --audit mode (read-only, no changes applied)."""
    return run_script(f"{SCRIPTS_BASE}/security/ssh_hardening.sh", ["--audit"])

@router.post("/ssh-harden", summary="Apply SSH hardening (CIS Benchmark)", response_model=ScriptResult)
async def ssh_harden(dry_run: bool = Query(False, description="Preview changes without applying")):
    """Applies CIS Benchmark Level 1 SSH hardening. Use dry_run=true to preview."""
    args = ["--dry-run"] if dry_run else []
    return run_script(f"{SCRIPTS_BASE}/security/ssh_hardening.sh", args)

@router.get("/failed-logins", summary="Failed login report", response_model=ScriptResult)
async def failed_logins(days: int = Query(7, ge=1, le=90, description="Days to look back")):
    """Parses auth logs and returns failed SSH/sudo login summary."""
    return run_script(f"{SCRIPTS_BASE}/security/failed_login_report.sh", [f"--days {days}"])
