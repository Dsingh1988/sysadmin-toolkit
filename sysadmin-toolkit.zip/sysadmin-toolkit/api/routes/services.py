"""Services API Routes"""
from fastapi import APIRouter, Query
from models.schemas import ScriptResult, run_script

router = APIRouter()
SCRIPTS_BASE = "../scripts"

@router.get("/sweep", summary="Systemd service health sweep", response_model=ScriptResult)
async def service_sweep(
    critical_only: bool = Query(False, description="Show only failed services"),
    auto_restart: bool = Query(False, description="Auto-restart failed services"),
):
    args = []
    if critical_only: args.append("--critical-only")
    if auto_restart:  args.append("--auto-restart")
    return run_script(f"{SCRIPTS_BASE}/services/service_health_sweep.sh", args)

@router.get("/pacemaker", summary="Pacemaker/DRBD cluster health", response_model=ScriptResult)
async def pacemaker_status():
    return run_script(f"{SCRIPTS_BASE}/services/pacemaker_status.sh", [])
