"""User Management API Routes"""
from fastapi import APIRouter
from models.schemas import ScriptResult, run_script

router = APIRouter()
SCRIPTS_BASE = "../scripts"

@router.get("/sudo-audit", summary="Sudo privilege audit", response_model=ScriptResult)
async def sudo_audit():
    return run_script(f"{SCRIPTS_BASE}/users/sudo_audit.sh", [])

@router.get("/stale-accounts", summary="Detect inactive/expired accounts", response_model=ScriptResult)
async def stale_accounts():
    return run_script(f"{SCRIPTS_BASE}/users/stale_account_audit.sh", [])
