---
name: 🐛 Bug Report
about: Report a script failure, wrong output, or OS compatibility issue
title: "[BUG] "
labels: bug
assignees: Dsingh1988
---

## 🐛 Bug Description
A clear description of what went wrong.

## 📋 Script & Version
- Script name: `scripts/disk/disk_health_check.sh`
- Version: (check header of script)

## 💻 Environment
- OS: (e.g. Rocky Linux 9.3, Ubuntu 22.04)
- Kernel: (`uname -r`)
- Run as root/sudo: Yes / No

## 🔁 Steps to Reproduce
```bash
sudo ./scripts/disk/disk_health_check.sh --threshold 80
```

## 📤 Actual Output
```
Paste full output here
```

## ✅ Expected Output
What should have happened?

## 📎 Additional Context
Any other details, logs, or screenshots.
