---
name: ✨ Feature Request
about: Suggest a new script or enhancement
title: "[FEAT] "
labels: enhancement
assignees: Dsingh1988
---

## ✨ Feature Description
What would you like to see added or improved?

## 🎯 Use Case
What problem does this solve? Who benefits?

## 💡 Proposed Approach
If you have ideas on implementation, share them here.

## 🖥️ Target Platform
- [ ] RHEL / Rocky Linux / AlmaLinux
- [ ] Ubuntu / Debian
- [ ] Both

## 📎 Additional Context
Links, references, or examples from other tools.
