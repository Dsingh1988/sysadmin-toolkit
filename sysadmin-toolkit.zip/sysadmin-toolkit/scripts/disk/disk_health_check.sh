#!/usr/bin/env bash
# =============================================================================
# disk_health_check.sh — Comprehensive Disk & Storage Health Checker
# =============================================================================
# Author  : Devendra Singh Chouhan <debuchouhan@gmail.com>
# GitHub  : https://github.com/Dsingh1988/sysadmin-toolkit
# License : MIT
# Version : 1.0.0
#
# Description:
#   Checks SMART status for all physical drives, LVM volume group usage,
#   and XFS/ext4 filesystem integrity. Designed for RHEL/Rocky/AlmaLinux
#   and Ubuntu enterprise environments.
#
# Usage:
#   sudo ./disk_health_check.sh [OPTIONS]
#
# Options:
#   -t, --threshold <N>    Alert if disk usage > N% (default: 85)
#   -e, --email <addr>     Send report to email address
#   -j, --json             Output results in JSON format
#   -q, --quiet            Only print warnings and errors
#   -h, --help             Show this help message
#
# Requirements:
#   - smartmontools (smartctl)
#   - lvm2
#   - mailx or sendmail (optional, for email reports)
#   - Root/sudo privileges
#
# Exit Codes:
#   0 — All checks passed
#   1 — One or more warnings detected
#   2 — One or more critical issues detected
# =============================================================================

set -euo pipefail

# ─── Constants ────────────────────────────────────────────────────────────────
readonly SCRIPT_NAME="$(basename "${BASH_SOURCE[0]}")"
readonly SCRIPT_VERSION="1.0.0"
readonly TIMESTAMP="$(date '+%Y-%m-%d %H:%M:%S')"
readonly LOG_FILE="/var/log/disk_health_check_$(date '+%Y%m%d').log"

# ─── Defaults ────────────────────────────────────────────────────────────────
THRESHOLD=85
EMAIL_TO=""
JSON_OUTPUT=false
QUIET=false
EXIT_CODE=0

# ─── Colors ───────────────────────────────────────────────────────────────────
RED='\033[0;31m'
YELLOW='\033[1;33m'
GREEN='\033[0;32m'
CYAN='\033[0;36m'
BOLD='\033[1m'
RESET='\033[0m'

# ─── Logging ─────────────────────────────────────────────────────────────────
log()  { echo -e "${CYAN}[INFO]${RESET}  $(date '+%H:%M:%S') $*" | tee -a "$LOG_FILE"; }
warn() { echo -e "${YELLOW}[WARN]${RESET}  $(date '+%H:%M:%S') $*" | tee -a "$LOG_FILE"; EXIT_CODE=1; }
crit() { echo -e "${RED}[CRIT]${RESET}  $(date '+%H:%M:%S') $*" | tee -a "$LOG_FILE"; EXIT_CODE=2; }
ok()   { [[ "$QUIET" == false ]] && echo -e "${GREEN}[ OK ]${RESET}  $(date '+%H:%M:%S') $*" | tee -a "$LOG_FILE"; }
header() {
  [[ "$QUIET" == false ]] && echo -e "\n${BOLD}${CYAN}══════════════════════════════════════════${RESET}"
  [[ "$QUIET" == false ]] && echo -e "${BOLD}${CYAN}  $*${RESET}"
  [[ "$QUIET" == false ]] && echo -e "${BOLD}${CYAN}══════════════════════════════════════════${RESET}"
}

# ─── Usage ───────────────────────────────────────────────────────────────────
usage() {
  cat <<EOF
${BOLD}${SCRIPT_NAME} v${SCRIPT_VERSION}${RESET}
Comprehensive disk and storage health checker for Linux enterprise environments.

${BOLD}USAGE:${RESET}
  sudo $SCRIPT_NAME [OPTIONS]

${BOLD}OPTIONS:${RESET}
  -t, --threshold <N>    Alert if disk usage > N%    (default: 85)
  -e, --email <addr>     Send report to email address
  -j, --json             Output results in JSON format
  -q, --quiet            Only print warnings and errors
  -h, --help             Show this help message

${BOLD}EXAMPLES:${RESET}
  sudo $SCRIPT_NAME
  sudo $SCRIPT_NAME --threshold 90 --email ops@company.com
  sudo $SCRIPT_NAME --json | python3 -m json.tool
  sudo $SCRIPT_NAME --quiet --email noc@company.com

${BOLD}EXIT CODES:${RESET}
  0  All checks passed
  1  One or more warnings
  2  One or more critical issues
EOF
}

# ─── Argument Parsing ─────────────────────────────────────────────────────────
parse_args() {
  while [[ $# -gt 0 ]]; do
    case "$1" in
      -t|--threshold) THRESHOLD="$2"; shift 2 ;;
      -e|--email)     EMAIL_TO="$2";  shift 2 ;;
      -j|--json)      JSON_OUTPUT=true; shift ;;
      -q|--quiet)     QUIET=true; shift ;;
      -h|--help)      usage; exit 0 ;;
      *) echo "Unknown option: $1"; usage; exit 1 ;;
    esac
  done
}

# ─── Preflight Checks ─────────────────────────────────────────────────────────
preflight_checks() {
  if [[ $EUID -ne 0 ]]; then
    echo -e "${RED}ERROR: This script must be run as root or with sudo.${RESET}"
    exit 1
  fi

  local missing=()
  for cmd in smartctl lsblk df pvs vgs lvs; do
    command -v "$cmd" &>/dev/null || missing+=("$cmd")
  done

  if [[ ${#missing[@]} -gt 0 ]]; then
    warn "Missing tools: ${missing[*]}. Install with: dnf install smartmontools lvm2"
  fi
}

# ─── Section 1: Filesystem Usage ─────────────────────────────────────────────
check_filesystem_usage() {
  header "FILESYSTEM USAGE"
  local issues=0

  while IFS= read -r line; do
    local usage mount
    usage=$(echo "$line" | awk '{print $5}' | tr -d '%')
    mount=$(echo "$line" | awk '{print $6}')

    # Skip pseudo filesystems
    [[ "$mount" =~ ^/(sys|proc|dev|run) ]] && continue

    if [[ "$usage" -ge 95 ]]; then
      crit "CRITICAL: $mount is ${usage}% full (threshold: ${THRESHOLD}%)"
      ((issues++))
    elif [[ "$usage" -ge "$THRESHOLD" ]]; then
      warn "WARNING:  $mount is ${usage}% full (threshold: ${THRESHOLD}%)"
      ((issues++))
    else
      ok "$mount — ${usage}% used"
    fi
  done < <(df -h --output=pcent,target | tail -n +2 | sed 's/[[:space:]]%//' || df -h | awk 'NR>1 {print $5, $6}')

  [[ $issues -eq 0 ]] && ok "All filesystems within threshold (${THRESHOLD}%)"
}

# ─── Section 2: SMART Disk Health ─────────────────────────────────────────────
check_smart_health() {
  header "SMART DISK HEALTH"

  if ! command -v smartctl &>/dev/null; then
    warn "smartctl not found — skipping SMART checks. Install: dnf install smartmontools"
    return
  fi

  local drives
  drives=$(lsblk -d -o NAME,TYPE | awk '$2=="disk"{print $1}')

  if [[ -z "$drives" ]]; then
    warn "No physical disks detected via lsblk"
    return
  fi

  for drive in $drives; do
    local dev="/dev/$drive"
    log "Checking SMART: $dev"

    # Check if SMART is supported
    if ! smartctl -i "$dev" &>/dev/null; then
      warn "$dev — SMART not supported or accessible"
      continue
    fi

    local health
    health=$(smartctl -H "$dev" 2>/dev/null | grep -i "overall-health" | awk '{print $NF}' || echo "UNKNOWN")

    if [[ "$health" == "PASSED" ]]; then
      ok "$dev — SMART health: PASSED"
    elif [[ "$health" == "FAILED!" ]]; then
      crit "$dev — SMART health: FAILED! Immediate attention required."
    else
      warn "$dev — SMART health: $health (check manually)"
    fi

    # Check reallocated sectors (early failure indicator)
    local reallocated
    reallocated=$(smartctl -A "$dev" 2>/dev/null | grep "Reallocated_Sector" | awk '{print $10}' || echo "0")
    if [[ "$reallocated" =~ ^[0-9]+$ ]] && [[ "$reallocated" -gt 0 ]]; then
      warn "$dev — Reallocated sectors: $reallocated (non-zero indicates physical degradation)"
    fi
  done
}

# ─── Section 3: LVM Volume Groups ─────────────────────────────────────────────
check_lvm_vgs() {
  header "LVM VOLUME GROUPS"

  if ! command -v vgs &>/dev/null; then
    warn "LVM tools not found — skipping VG checks"
    return
  fi

  local vg_count
  vg_count=$(vgs --noheadings 2>/dev/null | wc -l)

  if [[ "$vg_count" -eq 0 ]]; then
    log "No LVM Volume Groups detected"
    return
  fi

  while IFS= read -r line; do
    local vg_name vfree
    vg_name=$(echo "$line" | awk '{print $1}')
    vfree=$(echo "$line" | awk '{print $7}')
    ok "VG: $vg_name — Free: $vfree"
  done < <(vgs --noheadings -o vg_name,pv_count,lv_count,snap_count,vg_attr,vg_size,vg_free 2>/dev/null)
}

# ─── Section 4: LVM Thin Pool Usage ──────────────────────────────────────────
check_thin_pools() {
  header "LVM THIN POOLS"

  if ! command -v lvs &>/dev/null; then
    warn "LVM tools not found — skipping thin pool checks"
    return
  fi

  local pool_count=0

  while IFS= read -r line; do
    [[ -z "$line" ]] && continue
    pool_count=$((pool_count + 1))

    local lv_name vg_name data_pct meta_pct
    lv_name=$(echo "$line" | awk '{print $1}')
    vg_name=$(echo "$line" | awk '{print $2}')
    data_pct=$(echo "$line" | awk '{print $3}' | cut -d. -f1)
    meta_pct=$(echo "$line" | awk '{print $4}' | cut -d. -f1)

    data_pct=${data_pct:-0}
    meta_pct=${meta_pct:-0}

    if [[ "$data_pct" -ge 90 ]] || [[ "$meta_pct" -ge 90 ]]; then
      crit "Thin Pool $vg_name/$lv_name — Data: ${data_pct}% | Metadata: ${meta_pct}% — CRITICAL"
    elif [[ "$data_pct" -ge "$THRESHOLD" ]] || [[ "$meta_pct" -ge 80 ]]; then
      warn "Thin Pool $vg_name/$lv_name — Data: ${data_pct}% | Metadata: ${meta_pct}% — WARNING"
    else
      ok "Thin Pool $vg_name/$lv_name — Data: ${data_pct}% | Metadata: ${meta_pct}%"
    fi
  done < <(lvs --noheadings -o lv_name,vg_name,data_percent,metadata_percent --select 'lv_layout=~thin.*pool' 2>/dev/null)

  [[ $pool_count -eq 0 ]] && log "No LVM thin pools detected"
}

# ─── Section 5: Inode Usage ───────────────────────────────────────────────────
check_inodes() {
  header "INODE USAGE"

  while IFS= read -r line; do
    local iuse mount
    iuse=$(echo "$line" | awk '{print $5}' | tr -d '%')
    mount=$(echo "$line" | awk '{print $6}')

    [[ "$mount" =~ ^/(sys|proc|dev|run|snap) ]] && continue
    [[ "$iuse" == "-" ]] && continue

    if [[ "$iuse" -ge 95 ]]; then
      crit "Inode CRITICAL: $mount — ${iuse}% inodes used"
    elif [[ "$iuse" -ge 85 ]]; then
      warn "Inode WARNING: $mount — ${iuse}% inodes used"
    else
      ok "Inodes $mount — ${iuse}% used"
    fi
  done < <(df -i | tail -n +2)
}

# ─── Summary ─────────────────────────────────────────────────────────────────
print_summary() {
  echo ""
  echo -e "${BOLD}════════════════════════════════════════════${RESET}"
  echo -e "${BOLD}  DISK HEALTH CHECK SUMMARY — $TIMESTAMP${RESET}"
  echo -e "${BOLD}════════════════════════════════════════════${RESET}"
  echo -e "  Host      : $(hostname -f)"
  echo -e "  Threshold : ${THRESHOLD}%"
  echo -e "  Log File  : $LOG_FILE"

  case $EXIT_CODE in
    0) echo -e "  Status    : ${GREEN}${BOLD}ALL CHECKS PASSED${RESET}" ;;
    1) echo -e "  Status    : ${YELLOW}${BOLD}WARNINGS DETECTED — review output above${RESET}" ;;
    2) echo -e "  Status    : ${RED}${BOLD}CRITICAL ISSUES FOUND — immediate action required${RESET}" ;;
  esac
  echo -e "${BOLD}════════════════════════════════════════════${RESET}"
}

# ─── Email Report ─────────────────────────────────────────────────────────────
send_email_report() {
  if [[ -z "$EMAIL_TO" ]]; then return; fi

  if command -v mailx &>/dev/null; then
    local subject="[Disk Health] $(hostname -s) — $(date '+%Y-%m-%d') — Exit: $EXIT_CODE"
    mailx -s "$subject" "$EMAIL_TO" < "$LOG_FILE"
    log "Report emailed to: $EMAIL_TO"
  else
    warn "mailx not found — cannot send email report"
  fi
}

# ─── Main ─────────────────────────────────────────────────────────────────────
main() {
  parse_args "$@"
  preflight_checks

  echo "" >> "$LOG_FILE"
  echo "=== Disk Health Check Run: $TIMESTAMP ===" >> "$LOG_FILE"

  if [[ "$QUIET" == false ]]; then
    echo -e "\n${BOLD}${CYAN}Linux SysAdmin Automation Toolkit — Disk Health Check v${SCRIPT_VERSION}${RESET}"
    echo -e "Host: $(hostname -f) | Threshold: ${THRESHOLD}% | Time: $TIMESTAMP\n"
  fi

  check_filesystem_usage
  check_smart_health
  check_lvm_vgs
  check_thin_pools
  check_inodes
  print_summary
  send_email_report

  exit $EXIT_CODE
}

main "$@"
