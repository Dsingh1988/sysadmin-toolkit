#!/usr/bin/env bash
# =============================================================================
# ssh_hardening.sh — CIS Benchmark SSH Configuration Enforcer
# =============================================================================
# Author  : Devendra Singh Chouhan <debuchouhan@gmail.com>
# GitHub  : https://github.com/Dsingh1988/sysadmin-toolkit
# License : MIT
# Version : 1.0.0
#
# Description:
#   Audits or enforces CIS Benchmark Level 1 SSH hardening settings.
#   Supports --audit-only mode (no changes) and --dry-run (preview changes).
#   Creates a timestamped backup of sshd_config before any modifications.
#
# Usage:
#   sudo ./ssh_hardening.sh                  # Apply hardening
#   sudo ./ssh_hardening.sh --audit          # Audit only, no changes
#   sudo ./ssh_hardening.sh --dry-run        # Preview changes
#   sudo ./ssh_hardening.sh --restore        # Restore from latest backup
#
# CIS Controls Applied:
#   5.2.1  — Ensure permissions on /etc/ssh/sshd_config are configured
#   5.2.2  — Ensure SSH access is limited
#   5.2.4  — Ensure SSH Protocol is not set to 1
#   5.2.5  — Ensure SSH LogLevel is appropriate
#   5.2.6  — Ensure SSH X11 forwarding is disabled
#   5.2.8  — Ensure SSH root login is disabled
#   5.2.9  — Ensure SSH PermitEmptyPasswords is disabled
#   5.2.10 — Ensure SSH PermitUserEnvironment is disabled
#   5.2.12 — Ensure only strong ciphers are used
#   5.2.13 — Ensure only strong MAC algorithms are used
#   5.2.14 — Ensure only strong Key Exchange algorithms are used
#   5.2.16 — Ensure SSH Idle Timeout Interval is configured
# =============================================================================

set -euo pipefail

readonly SCRIPT_VERSION="1.0.0"
readonly SSHD_CONFIG="/etc/ssh/sshd_config"
readonly BACKUP_DIR="/etc/ssh/backups"
readonly TIMESTAMP="$(date '+%Y%m%d_%H%M%S')"
readonly LOG_FILE="/var/log/ssh_hardening_${TIMESTAMP}.log"

# ─── Modes ───────────────────────────────────────────────────────────────────
AUDIT_ONLY=false
DRY_RUN=false
RESTORE=false
PASS=0
FAIL=0
WARN_COUNT=0

# ─── Colors ───────────────────────────────────────────────────────────────────
RED='\033[0;31m'; YELLOW='\033[1;33m'; GREEN='\033[0;32m'
CYAN='\033[0;36m'; BOLD='\033[1m'; RESET='\033[0m'

log()    { echo -e "${CYAN}[INFO]${RESET} $*" | tee -a "$LOG_FILE"; }
pass()   { echo -e "${GREEN}[PASS]${RESET} $*" | tee -a "$LOG_FILE"; ((PASS++)); }
fail()   { echo -e "${RED}[FAIL]${RESET} $*" | tee -a "$LOG_FILE"; ((FAIL++)); }
fixed()  { echo -e "${GREEN}[FIXED]${RESET} $*" | tee -a "$LOG_FILE"; ((PASS++)); }
preview(){ echo -e "${YELLOW}[DRY-RUN]${RESET} Would set: $*" | tee -a "$LOG_FILE"; }
header() { echo -e "\n${BOLD}${CYAN}─── $* ───${RESET}" | tee -a "$LOG_FILE"; }

# ─── Argument Parsing ─────────────────────────────────────────────────────────
parse_args() {
  while [[ $# -gt 0 ]]; do
    case "$1" in
      --audit|-a)    AUDIT_ONLY=true; shift ;;
      --dry-run|-d)  DRY_RUN=true; shift ;;
      --restore|-r)  RESTORE=true; shift ;;
      --help|-h)
        echo "Usage: sudo $0 [--audit|--dry-run|--restore]"
        exit 0 ;;
      *) echo "Unknown option: $1"; exit 1 ;;
    esac
  done
}

# ─── Preflight ────────────────────────────────────────────────────────────────
preflight() {
  [[ $EUID -ne 0 ]] && { echo "Run as root."; exit 1; }
  [[ ! -f "$SSHD_CONFIG" ]] && { echo "sshd_config not found at $SSHD_CONFIG"; exit 1; }
  mkdir -p "$BACKUP_DIR"
}

# ─── Backup ───────────────────────────────────────────────────────────────────
backup_config() {
  local backup="${BACKUP_DIR}/sshd_config.${TIMESTAMP}.bak"
  cp "$SSHD_CONFIG" "$backup"
  log "Backup created: $backup"
}

# ─── Restore ──────────────────────────────────────────────────────────────────
restore_config() {
  local latest
  latest=$(ls -t "${BACKUP_DIR}"/sshd_config.*.bak 2>/dev/null | head -1)
  if [[ -z "$latest" ]]; then
    echo "No backups found in $BACKUP_DIR"
    exit 1
  fi
  cp "$latest" "$SSHD_CONFIG"
  echo "Restored from: $latest"
  systemctl reload sshd && echo "sshd reloaded."
  exit 0
}

# ─── Core: Check/Set Parameter ───────────────────────────────────────────────
# check_set <param> <expected_value> <cis_id> <description>
check_set() {
  local param="$1" expected="$2" cis_id="$3" desc="$4"
  local current
  current=$(grep -i "^${param}" "$SSHD_CONFIG" | awk '{print $2}' | head -1 || echo "")

  if [[ "$current" == "$expected" ]]; then
    pass "CIS $cis_id: $desc — $param=$expected"
  elif [[ "$AUDIT_ONLY" == true ]]; then
    fail "CIS $cis_id: $desc — $param is '${current:-unset}', expected '$expected'"
  elif [[ "$DRY_RUN" == true ]]; then
    preview "$param $expected"
  else
    # Remove existing entry and append correct value
    sed -i "/^#*${param}/d" "$SSHD_CONFIG"
    echo "${param} ${expected}" >> "$SSHD_CONFIG"
    fixed "CIS $cis_id: $desc — set $param=$expected"
  fi
}

# ─── Checks ───────────────────────────────────────────────────────────────────
run_checks() {
  header "5.2 SSH Server Configuration"

  # Protocol
  check_set "Protocol" "2" "5.2.4" "SSH Protocol version"

  # Logging
  check_set "LogLevel" "VERBOSE" "5.2.5" "SSH LogLevel"

  # Root Login
  check_set "PermitRootLogin" "no" "5.2.8" "Disable root SSH login"

  # Empty Passwords
  check_set "PermitEmptyPasswords" "no" "5.2.9" "Disable empty passwords"

  # User Environment
  check_set "PermitUserEnvironment" "no" "5.2.10" "Disable user environment"

  # X11 Forwarding
  check_set "X11Forwarding" "no" "5.2.6" "Disable X11 forwarding"

  # Idle Timeout: 15 minutes (900 seconds)
  check_set "ClientAliveInterval" "300" "5.2.16" "Set idle interval (300s)"
  check_set "ClientAliveCountMax" "3" "5.2.16" "Set client alive count (3)"

  # Max Auth Tries
  check_set "MaxAuthTries" "4" "5.2.7" "Limit auth attempts"

  # Ignore Rhosts
  check_set "IgnoreRhosts" "yes" "5.2.11" "Ignore .rhosts files"

  # Host Based Auth
  check_set "HostbasedAuthentication" "no" "5.2.11" "Disable host-based auth"

  # Password Auth (enforce key-based)
  check_set "PasswordAuthentication" "no" "5.2.15" "Disable password auth (keys only)"

  # Ciphers (strong only)
  local strong_ciphers="aes256-gcm@openssh.com,aes128-gcm@openssh.com,aes256-ctr,aes192-ctr,aes128-ctr"
  check_set "Ciphers" "$strong_ciphers" "5.2.12" "Enforce strong ciphers"

  # MACs
  local strong_macs="hmac-sha2-512-etm@openssh.com,hmac-sha2-256-etm@openssh.com,hmac-sha2-512,hmac-sha2-256"
  check_set "MACs" "$strong_macs" "5.2.13" "Enforce strong MACs"

  # KexAlgorithms
  local strong_kex="curve25519-sha256,curve25519-sha256@libssh.org,diffie-hellman-group14-sha256,diffie-hellman-group16-sha512"
  check_set "KexAlgorithms" "$strong_kex" "5.2.14" "Enforce strong KexAlgorithms"

  # Permissions check
  header "5.2.1 File Permissions"
  local perms
  perms=$(stat -c "%a" "$SSHD_CONFIG")
  if [[ "$perms" == "600" ]] || [[ "$perms" == "640" ]]; then
    pass "CIS 5.2.1: sshd_config permissions are $perms"
  else
    fail "CIS 5.2.1: sshd_config permissions are $perms (expected 600)"
    if [[ "$AUDIT_ONLY" == false ]] && [[ "$DRY_RUN" == false ]]; then
      chmod 600 "$SSHD_CONFIG"
      chown root:root "$SSHD_CONFIG"
      fixed "CIS 5.2.1: Set permissions to 600"
    fi
  fi
}

# ─── Validate & Reload ────────────────────────────────────────────────────────
validate_and_reload() {
  if [[ "$AUDIT_ONLY" == true ]] || [[ "$DRY_RUN" == true ]]; then return; fi

  log "Validating sshd_config syntax..."
  if sshd -t -f "$SSHD_CONFIG" 2>&1 | tee -a "$LOG_FILE"; then
    log "Config syntax valid."
    log "Reloading sshd..."
    systemctl reload sshd && log "sshd reloaded successfully."
  else
    fail "sshd_config has syntax errors! Restoring backup..."
    restore_config
    exit 2
  fi
}

# ─── Summary ─────────────────────────────────────────────────────────────────
print_summary() {
  echo ""
  echo -e "${BOLD}═══════════════════════════════════════════${RESET}"
  echo -e "${BOLD}  SSH HARDENING SUMMARY${RESET}"
  echo -e "${BOLD}═══════════════════════════════════════════${RESET}"
  echo -e "  Mode    : $(${AUDIT_ONLY} && echo 'AUDIT ONLY' || (${DRY_RUN} && echo 'DRY RUN' || echo 'APPLY'))"
  echo -e "  Host    : $(hostname -f)"
  echo -e "  ${GREEN}PASSED  : $PASS${RESET}"
  echo -e "  ${RED}FAILED  : $FAIL${RESET}"
  echo -e "  Log     : $LOG_FILE"

  if [[ $FAIL -eq 0 ]]; then
    echo -e "  ${GREEN}${BOLD}Result  : ALL CIS CHECKS PASSED${RESET}"
  else
    echo -e "  ${YELLOW}${BOLD}Result  : $FAIL CHECK(S) REQUIRE ATTENTION${RESET}"
  fi
  echo -e "${BOLD}═══════════════════════════════════════════${RESET}"
}

# ─── Main ─────────────────────────────────────────────────────────────────────
main() {
  parse_args "$@"
  preflight
  [[ "$RESTORE" == true ]] && restore_config

  echo -e "${BOLD}${CYAN}SSH Hardening Script v${SCRIPT_VERSION} — $(date '+%Y-%m-%d %H:%M:%S')${RESET}"
  echo -e "Config: $SSHD_CONFIG | Mode: $(${AUDIT_ONLY} && echo AUDIT || (${DRY_RUN} && echo DRY-RUN || echo APPLY))\n"

  [[ "$AUDIT_ONLY" == false ]] && [[ "$DRY_RUN" == false ]] && backup_config

  run_checks
  validate_and_reload
  print_summary

  [[ $FAIL -gt 0 ]] && exit 1 || exit 0
}

main "$@"
