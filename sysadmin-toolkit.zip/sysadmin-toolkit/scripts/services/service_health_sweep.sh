#!/usr/bin/env bash
# =============================================================================
# service_health_sweep.sh — Systemd Service Health Checker with Auto-Remediation
# =============================================================================
# Author  : Devendra Singh Chouhan <debuchouhan@gmail.com>
# GitHub  : https://github.com/Dsingh1988/sysadmin-toolkit
# License : MIT
# Version : 1.0.0
#
# Description:
#   Sweeps all systemd units, identifies failed/degraded/inactive-dead services,
#   optionally attempts auto-restart, and produces a color-coded status report.
#
# Usage:
#   ./service_health_sweep.sh [OPTIONS]
#
# Options:
#   -a, --auto-restart     Attempt to restart failed services
#   -c, --critical-only    Only show failed/degraded services
#   -w, --whitelist <f>    File listing services to skip (one per line)
#   -e, --email <addr>     Email the report
#   -j, --json             Output JSON format
#   -h, --help             Show help
# =============================================================================

set -euo pipefail

readonly SCRIPT_VERSION="1.0.0"
readonly TIMESTAMP="$(date '+%Y-%m-%d %H:%M:%S')"
readonly LOG_FILE="/var/log/service_sweep_$(date '+%Y%m%d_%H%M%S').log"

AUTO_RESTART=false
CRITICAL_ONLY=false
EMAIL_TO=""
JSON_OUTPUT=false
WHITELIST_FILE=""

FAILED_SERVICES=()
RESTARTED_SERVICES=()
RUNNING_COUNT=0
FAILED_COUNT=0
INACTIVE_COUNT=0

RED='\033[0;31m'; YELLOW='\033[1;33m'; GREEN='\033[0;32m'
CYAN='\033[0;36m'; BOLD='\033[1m'; RESET='\033[0m'

log()    { echo -e "${CYAN}[INFO]${RESET} $(date '+%H:%M:%S') $*" | tee -a "$LOG_FILE"; }
ok()     { echo -e "${GREEN}[ OK ]${RESET} $*" | tee -a "$LOG_FILE"; }
fail()   { echo -e "${RED}[FAIL]${RESET} $*" | tee -a "$LOG_FILE"; }
warn()   { echo -e "${YELLOW}[WARN]${RESET} $*" | tee -a "$LOG_FILE"; }
header() { echo -e "\n${BOLD}${CYAN}══ $* ══${RESET}" | tee -a "$LOG_FILE"; }

parse_args() {
  while [[ $# -gt 0 ]]; do
    case "$1" in
      -a|--auto-restart)  AUTO_RESTART=true; shift ;;
      -c|--critical-only) CRITICAL_ONLY=true; shift ;;
      -e|--email)         EMAIL_TO="$2"; shift 2 ;;
      -j|--json)          JSON_OUTPUT=true; shift ;;
      -w|--whitelist)     WHITELIST_FILE="$2"; shift 2 ;;
      -h|--help)
        echo "Usage: $0 [--auto-restart] [--critical-only] [--email addr] [--whitelist file]"
        exit 0 ;;
      *) echo "Unknown: $1"; exit 1 ;;
    esac
  done
}

is_whitelisted() {
  local svc="$1"
  [[ -z "$WHITELIST_FILE" ]] && return 1
  [[ -f "$WHITELIST_FILE" ]] && grep -qx "$svc" "$WHITELIST_FILE" && return 0
  return 1
}

sweep_services() {
  header "SYSTEMD SERVICE STATUS SWEEP"
  log "Host: $(hostname -f) | Sweep started: $TIMESTAMP"

  while IFS= read -r line; do
    local unit state sub
    unit=$(echo "$line"  | awk '{print $1}')
    state=$(echo "$line" | awk '{print $3}')
    sub=$(echo "$line"   | awk '{print $4}')

    # Skip non-service units and template units
    [[ "$unit" != *.service ]] && continue
    [[ "$unit" == *@* ]] && continue

    local svc_name="${unit%.service}"

    is_whitelisted "$svc_name" && { log "Skipping (whitelisted): $unit"; continue; }

    case "$state" in
      active)
        ((RUNNING_COUNT++))
        [[ "$CRITICAL_ONLY" == false ]] && ok "$unit — active ($sub)"
        ;;
      failed)
        ((FAILED_COUNT++))
        FAILED_SERVICES+=("$unit")
        fail "$unit — FAILED (exit-code: $(systemctl show "$unit" -p ExecMainStatus --value 2>/dev/null || echo '?'))"

        if [[ "$AUTO_RESTART" == true ]]; then
          log "Attempting restart: $unit"
          if systemctl restart "$unit" 2>/dev/null; then
            RESTARTED_SERVICES+=("$unit")
            ok "Auto-restarted: $unit"
          else
            warn "Auto-restart FAILED for: $unit"
          fi
        fi
        ;;
      inactive)
        ((INACTIVE_COUNT++))
        [[ "$CRITICAL_ONLY" == false ]] && warn "$unit — inactive ($sub)"
        ;;
    esac

  done < <(systemctl list-units --type=service --all --no-pager --no-legend 2>/dev/null)
}

print_json() {
  python3 - <<EOF
import json, sys

data = {
    "host": "$(hostname -f)",
    "timestamp": "$TIMESTAMP",
    "summary": {
        "running": $RUNNING_COUNT,
        "failed": $FAILED_COUNT,
        "inactive": $INACTIVE_COUNT
    },
    "failed_services": $(printf '%s\n' "${FAILED_SERVICES[@]+"${FAILED_SERVICES[@]}"}" | python3 -c "import sys,json; print(json.dumps([l.strip() for l in sys.stdin if l.strip()]))"),
    "restarted_services": $(printf '%s\n' "${RESTARTED_SERVICES[@]+"${RESTARTED_SERVICES[@]}"}" | python3 -c "import sys,json; print(json.dumps([l.strip() for l in sys.stdin if l.strip()]))")
}
print(json.dumps(data, indent=2))
EOF
}

print_summary() {
  echo ""
  echo -e "${BOLD}═══════════════════════════════════════════${RESET}"
  echo -e "${BOLD}  SERVICE HEALTH SWEEP — SUMMARY${RESET}"
  echo -e "${BOLD}═══════════════════════════════════════════${RESET}"
  echo -e "  Host     : $(hostname -f)"
  echo -e "  ${GREEN}Running  : $RUNNING_COUNT${RESET}"
  echo -e "  ${YELLOW}Inactive : $INACTIVE_COUNT${RESET}"
  echo -e "  ${RED}Failed   : $FAILED_COUNT${RESET}"

  if [[ ${#RESTARTED_SERVICES[@]} -gt 0 ]]; then
    echo -e "\n  ${CYAN}Auto-Restarted:${RESET}"
    for svc in "${RESTARTED_SERVICES[@]}"; do
      echo -e "    ✓ $svc"
    done
  fi

  if [[ ${#FAILED_SERVICES[@]} -gt 0 ]]; then
    echo -e "\n  ${RED}Still Failed:${RESET}"
    for svc in "${FAILED_SERVICES[@]}"; do
      local restarted=false
      for r in "${RESTARTED_SERVICES[@]+"${RESTARTED_SERVICES[@]}"}"; do
        [[ "$r" == "$svc" ]] && restarted=true
      done
      [[ "$restarted" == false ]] && echo -e "    ✗ $svc"
    done
    echo -e "\n  Diagnose: journalctl -u <service> --since today"
  fi

  [[ $FAILED_COUNT -eq 0 ]] && echo -e "\n  ${GREEN}${BOLD}All monitored services are healthy.${RESET}"
  echo -e "${BOLD}═══════════════════════════════════════════${RESET}"
  echo -e "  Log: $LOG_FILE"
}

main() {
  parse_args "$@"

  echo -e "${BOLD}${CYAN}Service Health Sweep v${SCRIPT_VERSION}${RESET}"

  sweep_services

  if [[ "$JSON_OUTPUT" == true ]]; then
    print_json
  else
    print_summary
  fi

  [[ $FAILED_COUNT -gt 0 ]] && exit 1 || exit 0
}

main "$@"
